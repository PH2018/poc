package com.poc.accountms.common;

public class AccountValidationConstant {
    public static final String VALIDATE_ACCOUNT_URI="/v1/account/validate";
    public static final String DEFAULT_MESSAGE="Please try after some time";
    public static final String BAD_REQUEST="400";
}
