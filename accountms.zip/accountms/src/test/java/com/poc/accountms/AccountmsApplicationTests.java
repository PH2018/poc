package com.poc.accountms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
