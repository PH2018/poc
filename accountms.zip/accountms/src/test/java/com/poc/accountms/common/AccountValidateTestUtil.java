package com.poc.accountms.common;

import com.poc.accountms.model.AccountValidationRequest;
import com.poc.accountms.model.DataProviderRequest;
import com.poc.accountms.model.DataProviderResponse;

import java.util.Arrays;
import java.util.List;

public class AccountValidateTestUtil {

    public static AccountValidationRequest createAccountValidationRequest(){
        AccountValidationRequest accountValidationRequest = new AccountValidationRequest();
        accountValidationRequest.setAccountNumber("12345678");
        List<String> providerNames = Arrays.asList("provider1","provider2");
        accountValidationRequest.setProviders(providerNames);
        return accountValidationRequest;
    }

    public static DataProviderRequest createDataProviderRequest(){
        DataProviderRequest dataProviderRequest = new DataProviderRequest();
        dataProviderRequest.setAccountNumber("12345678");
        return dataProviderRequest;
    }

    public static DataProviderResponse creteDataProviderResponse(){
        DataProviderResponse dataProviderResponse = new DataProviderResponse();
        dataProviderResponse.setValid(true);
        return dataProviderResponse;
    }

}
